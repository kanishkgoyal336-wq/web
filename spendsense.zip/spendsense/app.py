"""
SpendSense — Web App (Flask)
============================
Upload your bank statement in the browser and get the full analysis.

Run:
    pip install -r requirements.txt
    python app.py
Then open  http://127.0.0.1:5000  in your browser.

Routes:
    GET  /                    -> upload page (templates/index.html)
    POST /analyze             -> receives the file, runs the pipeline, shows the report
    GET  /sample              -> runs the analysis on the built-in sample statement
    GET  /download/<id>       -> download the categorized transactions as CSV

Everything runs on your own computer — your statement is never sent anywhere.
"""

import shutil
import tempfile
import uuid
from pathlib import Path

from flask import Flask, abort, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

from src import StatementError
from src.pipeline import analyze_statement

BASE = Path(__file__).resolve().parent
SAMPLE = BASE / "data" / "sample_statement.csv"
WORK = Path(tempfile.gettempdir()) / "spendsense_runs"   # temporary results
ALLOWED = {".csv", ".xlsx", ".xls"}
MAX_RUNS_KEPT = 20

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024   # 10 MB upload limit


def _cleanup_old_runs():
    """Keep only the most recent runs so temp files don't pile up."""
    if not WORK.exists():
        return
    runs = sorted(WORK.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in runs[MAX_RUNS_KEPT:]:
        shutil.rmtree(old, ignore_errors=True)


def _toolbar(run_id: str) -> str:
    return (f'<div class="toolbar">'
            f'<a class="btn" href="{url_for("download_csv", run_id=run_id)}">⬇ Download categorized CSV</a>'
            f'<a class="btn" href="javascript:window.print()">🖨 Print / Save PDF</a>'
            f'<a class="btn primary" href="{url_for("index")}">＋ Analyze another statement</a></div>')


def _run(statement_path: Path, name: str, run_dir: Path, run_id: str):
    result = analyze_statement(statement_path, run_dir, name=name or None, toolbar=_toolbar(run_id))
    return result["report"].read_text(encoding="utf-8")


@app.get("/")
def index():
    return render_template("index.html", error=None)


@app.post("/analyze")
def analyze():
    file = request.files.get("statement")
    name = request.form.get("name", "").strip()[:40]

    if not file or not file.filename:
        return render_template("index.html", error="Please choose a statement file first."), 400

    filename = secure_filename(file.filename) or "statement.csv"
    if Path(filename).suffix.lower() not in ALLOWED:
        return render_template("index.html", error="Only .csv, .xlsx or .xls files are supported."), 400

    _cleanup_old_runs()
    run_id = uuid.uuid4().hex
    run_dir = WORK / run_id
    run_dir.mkdir(parents=True)
    saved = run_dir / filename
    file.save(saved)

    try:
        return _run(saved, name, run_dir, run_id)
    except StatementError as e:
        shutil.rmtree(run_dir, ignore_errors=True)
        return render_template("index.html", error=str(e)), 400
    except Exception as e:  # unexpected file layout etc.
        shutil.rmtree(run_dir, ignore_errors=True)
        return render_template("index.html",
                               error=f"Could not read this file ({type(e).__name__}). "
                                     "Make sure the first row contains the column names."), 400


@app.get("/sample")
def sample():
    if not SAMPLE.exists():
        return redirect(url_for("index"))
    _cleanup_old_runs()
    run_id = uuid.uuid4().hex
    return _run(SAMPLE, "Sample", WORK / run_id, run_id)


@app.get("/download/<run_id>")
def download_csv(run_id):
    if not run_id.isalnum():
        abort(404)
    path = WORK / run_id / "categorized_transactions.csv"
    if not path.exists():
        abort(404)
    return send_file(path, as_attachment=True, download_name="categorized_transactions.csv")


@app.errorhandler(413)
def too_large(_):
    return render_template("index.html", error="File is too large (max 10 MB)."), 413


if __name__ == "__main__":
    print("\n  SpendSense is running →  http://127.0.0.1:5000\n")
    app.run(debug=False, port=5000)
