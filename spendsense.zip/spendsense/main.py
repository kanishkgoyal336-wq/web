"""
SpendSense — command-line version
=================================
Usage:
    python main.py data/sample_statement.csv
    python main.py my_statement.xlsx --out output --name "Kanish"

For the web version (upload in the browser), run:  python app.py
"""

import argparse
import sys

from src import StatementError, print_console_summary
from src.pipeline import analyze_statement


def main():
    p = argparse.ArgumentParser(description="Analyze a bank statement and explain your expenses.")
    p.add_argument("statement", help="Path to bank statement (.csv / .xlsx)")
    p.add_argument("--out", default="output", help="Output folder (default: output)")
    p.add_argument("--rules", help="Custom categories.json file")
    p.add_argument("--name", help="Your name, shown in the report title")
    a = p.parse_args()
    try:
        r = analyze_statement(a.statement, a.out, a.name, a.rules, verbose=True)
    except StatementError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    print_console_summary(r["results"], r["insights"])
    print(f"\n  Report  : {r['report'].resolve()}")
    print(f"  Data    : {r['csv'].resolve()}\n")


if __name__ == "__main__":
    main()
