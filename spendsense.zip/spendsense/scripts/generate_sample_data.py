"""
Generates a realistic 6-month sample bank statement for a college student,
in the column format used by many Indian banks:

    Date | Narration | Withdrawal Amt. | Deposit Amt. | Closing Balance

Run:  python scripts/generate_sample_data.py
"""

import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(42)
START, MONTHS = date(2026, 4, 1), 6
OUT = Path(__file__).resolve().parent.parent / "data" / "sample_statement.csv"

# (narration template, min, max, avg times per month, weekend-heavy?)
VARIABLE = [
    ("UPI/{r}/SWIGGY/swiggy@icici", 150, 520, 9, True),
    ("UPI/{r}/ZOMATO/zomato@hdfcbank", 180, 600, 6, True),
    ("UPI/{r}/COLLEGE CANTEEN/canteen@ybl", 40, 140, 12, False),
    ("UPI/{r}/BLINKIT/blinkit@axl", 120, 700, 4, False),
    ("UPI/{r}/UBER INDIA/uber@icici", 90, 380, 5, True),
    ("UPI/{r}/RAPIDO/rapido@ybl", 40, 150, 6, False),
    ("POS/{r}/AMAZON PAY INDIA", 299, 1500, 2, False),
    ("POS/{r}/FLIPKART INTERNET", 349, 1800, 1, False),
    ("UPI/{r}/HPCL PETROL PUMP/hpcl@sbi", 300, 600, 3, False),
    ("UPI/{r}/BOOKMYSHOW/bms@icici", 250, 700, 1, True),
    ("UPI/{r}/APOLLO PHARMACY/apollo@ybl", 80, 450, 1, False),
    ("UPI/{r}/STARBUCKS/starbucks@hdfc", 280, 520, 1, True),
    ("UPI/P2P/{r}/RAHUL SHARMA/rahul@oksbi", 100, 800, 2, False),
    ("ATM CASH WDL/{r}/SBI ATM SECTOR 17", 500, 2000, 1, False),
]

FIXED = [  # (day of month, narration, amount)
    (5, "ACH/NETFLIX/{r}", 199),
    (8, "UPI/{r}/SPOTIFY INDIA/spotify@icici", 119),
    (12, "UPI/{r}/AIRTEL PREPAID RECHARGE/airtel@ybl", 349),
    (2, "NEFT/{r}/PG RENT MR VERMA", 6500),
    (10, "UPI/{r}/CULT.FIT GYM/cultfit@icici", 999),
    (15, "ACH/GROWW SIP/{r}", 1000),
]

INCOME = [
    (1, "NEFT/{r}/POCKET MONEY FROM DAD", 20000),
    (20, "IMPS/{r}/INTERNSHIP STIPEND XYZ TECH", 12000),
]


def ref():
    return str(random.randint(400000000000, 499999999999))


def build():
    rows = []
    for m in range(MONTHS):
        first = date(START.year + (START.month - 1 + m) // 12, (START.month - 1 + m) % 12 + 1, 1)
        nxt = date(first.year + first.month // 12, first.month % 12 + 1, 1)
        days = (nxt - first).days

        for day, narr, amt in INCOME:
            if "STIPEND" in narr and m < 2:
                continue  # internship started in month 3
            rows.append((first.replace(day=day), narr.format(r=ref()), 0, amt))
        for day, narr, amt in FIXED:
            rows.append((first.replace(day=day), narr.format(r=ref()), amt, 0))
        for narr, lo, hi, freq, weekend in VARIABLE:
            n = max(0, round(random.gauss(freq * (1.25 if m == 4 else 1), freq * 0.3)))
            for _ in range(n):
                d = first + timedelta(days=random.randrange(days))
                if weekend and d.weekday() < 5 and random.random() < 0.5:
                    d += timedelta(days=5 - d.weekday())  # push to Saturday
                    if d >= nxt:
                        d = nxt - timedelta(days=1)
                rows.append((d, narr.format(r=ref()), round(random.uniform(lo, hi), 2), 0))

        if m == 3:  # one-off big expenses -> should be flagged as unusual
            rows.append((first.replace(day=18), f"POS/{ref()}/AMAZON PAY INDIA HEADPHONES", 7499, 0))
        if m == 2:
            rows.append((first.replace(day=7), f"NEFT/{ref()}/UNIVERSITY EXAM FEES", 4500, 0))
        if m == 4:
            rows.append((first.replace(day=24), f"UPI/{ref()}/IRCTC TRAIN TICKET/irctc@sbi", 1850, 0))
            rows.append((first.replace(day=9), f"NEFT/{ref()}/AMAZON REFUND", 0, 649))

    df = pd.DataFrame(rows, columns=["Date", "Narration", "Withdrawal Amt.", "Deposit Amt."])
    df = df.sort_values("Date", kind="stable").reset_index(drop=True)
    df["Closing Balance"] = (25000 + (df["Deposit Amt."] - df["Withdrawal Amt."]).cumsum()).round(2)
    df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%d/%m/%Y")
    df["Withdrawal Amt."] = df["Withdrawal Amt."].replace(0, "")
    df["Deposit Amt."] = df["Deposit Amt."].replace(0, "")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT, index=False)
    print(f"Wrote {len(df)} transactions to {OUT}")


if __name__ == "__main__":
    build()
