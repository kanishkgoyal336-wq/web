"""Unit tests — run with:  python -m pytest -q   (or  python -m unittest)"""

import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import Analyzer, Categorizer, StatementError, clean_statement, generate_insights, inr


def sample_df():
    raw = pd.DataFrame({
        "Txn Date": ["01/04/2026", "02/04/2026", "05/04/2026", "03/05/2026", "05/05/2026", "05/06/2026"],
        "Narration": ["NEFT/1/POCKET MONEY", "UPI/2/SWIGGY/x@icici", "ACH/NETFLIX/3",
                      "UPI/4/UBER INDIA/u@icici", "ACH/NETFLIX/5", "ACH/NETFLIX/6"],
        "Withdrawal Amt.": ["", "450.50", "199", "1,200", "199", "199"],
        "Deposit Amt.": ["15,000", "", "", "", "", ""],
        "Closing Balance": [15000, 14549.5, 14350.5, 13150.5, 12951.5, 12752.5],
    })
    return Categorizer().apply(clean_statement(raw))


class TestLoader(unittest.TestCase):
    def test_column_aliases_and_numbers(self):
        df = sample_df()
        self.assertListEqual(list(df.columns[:5]), ["date", "description", "debit", "credit", "balance"])
        self.assertEqual(df["credit"].sum(), 15000)
        self.assertAlmostEqual(df["debit"].sum(), 450.5 + 199 * 3 + 1200)

    def test_day_first_dates(self):
        self.assertEqual(sample_df()["date"].iloc[1].month, 4)  # 02/04 = 2 April

    def test_single_amount_column(self):
        raw = pd.DataFrame({"Date": ["01/01/2026", "02/01/2026"],
                            "Description": ["Salary", "Zomato"], "Amount": [5000, -300]})
        df = clean_statement(raw)
        self.assertEqual(df["credit"].sum(), 5000)
        self.assertEqual(df["debit"].sum(), 300)

    def test_bad_file_raises(self):
        with self.assertRaises(StatementError):
            clean_statement(pd.DataFrame({"foo": [1], "bar": [2]}))


class TestCategorizer(unittest.TestCase):
    def test_categories(self):
        c = Categorizer()
        self.assertEqual(c.categorize("UPI/123/SWIGGY", False), "Food & Dining")
        self.assertEqual(c.categorize("UPI/123/UBER INDIA", False), "Travel & Transport")
        self.assertEqual(c.categorize("AMAZON REFUND", True), "Income")
        self.assertEqual(c.categorize("RANDOM SHOP XYZ", False), "Others")

    def test_merchant_extraction(self):
        self.assertEqual(Categorizer.merchant("UPI/412345678/SWIGGY/swiggy@icici"), "Swiggy")


class TestAnalyzer(unittest.TestCase):
    def setUp(self):
        self.results = Analyzer(sample_df()).run_all()

    def test_summary(self):
        s = self.results["summary"]
        self.assertEqual(s["total_income"], 15000)
        self.assertEqual(s["transactions"], 6)
        self.assertGreater(s["savings_rate"], 0)

    def test_category_shares_sum_to_100(self):
        self.assertAlmostEqual(self.results["by_category"]["share_pct"].sum(), 100)

    def test_recurring_detects_netflix(self):
        self.assertIn("Netflix", list(self.results["recurring"]["merchant"]))

    def test_insights_generated(self):
        self.assertTrue(len(generate_insights(self.results)) >= 3)


class TestFormatting(unittest.TestCase):
    def test_indian_rupee_format(self):
        self.assertEqual(inr(1234567), "₹12,34,567")
        self.assertEqual(inr(999), "₹999")
        self.assertEqual(inr(-15000), "-₹15,000")


if __name__ == "__main__":
    unittest.main()
