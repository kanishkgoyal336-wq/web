# SpendSense — Bank Statement Analytics System

A Python application that reads your bank statement (CSV or Excel), automatically
categorizes every transaction, analyzes your spending patterns and explains them
in plain English — with charts and a shareable HTML report.

**Author:** Kanish Goyal · BCA (Data Science), 3rd Semester

---

## 1. Problem Statement

Bank statements list hundreds of transactions with cryptic narrations like
`UPI/415187984005/SWIGGY/swiggy@icici`. They tell you *what* happened but not
*where your money is going*, *which habits cost the most*, or *whether you are saving
enough*. SpendSense turns a raw statement into answers to those questions.

## 2. Objectives

1. Accept statements from different banks despite different column names.
2. Automatically categorize transactions (Food, Travel, Shopping, Bills, …).
3. Compute key financial metrics — income, spending, savings rate, trends.
4. Detect patterns: recurring payments (subscriptions/EMIs) and unusual transactions.
5. Explain the findings in simple language, not just numbers.
6. Present everything visually in a single report.

## 3. System Architecture

```
 Bank statement (.csv / .xlsx)
            │
            ▼
 ┌─────────────────────────┐  src/loader.py
 │ 1. LOADER & CLEANER     │  • maps bank-specific column names to a standard schema
 │                         │  • parses dates (dd/mm/yyyy), cleans '₹1,250.00' → 1250.0
 └───────────┬─────────────┘  • supports Debit/Credit columns OR single Amount column
             ▼
 ┌─────────────────────────┐  src/categorizer.py + config/categories.json
 │ 2. CATEGORIZER          │  • keyword rules → category (Swiggy → Food & Dining)
 │                         │  • extracts short merchant name from narration
 └───────────┬─────────────┘
             ▼
 ┌─────────────────────────┐  src/analyzer.py
 │ 3. ANALYZER             │  • summary KPIs, category split, monthly trend
 │                         │  • weekday pattern, top merchants, balance trend
 │                         │  • recurring payments (coefficient of variation)
 └───────────┬─────────────┘  • anomalies (z-score per category)
             ▼
 ┌─────────────────────────┐  src/insights.py
 │ 4. INSIGHT ENGINE       │  • rule-based natural-language explanations
 └───────────┬─────────────┘  • flags: good ✅ / warning ⚠️ / info 💡
             ▼
 ┌─────────────────────────┐  src/visualizer.py + src/report.py
 │ 5. VISUALIZER & REPORT  │  • 5 matplotlib charts
 │                         │  • self-contained HTML report + console summary
 └─────────────────────────┘  • CSV exports of categorized data
```

### Standard data schema (after cleaning)

| Column        | Type     | Meaning                                  |
|---------------|----------|------------------------------------------|
| `date`        | datetime | Transaction date                         |
| `description` | str      | Bank narration                           |
| `debit`       | float    | Money out (0 if credit)                  |
| `credit`      | float    | Money in (0 if debit)                    |
| `balance`     | float    | Closing balance (if bank provides it)    |
| `amount`      | float    | credit − debit (signed)                  |
| `month`       | str      | `YYYY-MM`                                |
| `weekday`     | str      | Monday … Sunday                          |
| `category`    | str      | Added by Categorizer                     |
| `merchant`    | str      | Added by Categorizer                     |

## 4. Analytics Techniques Used

| Feature                 | Technique                                                                 |
|-------------------------|---------------------------------------------------------------------------|
| Categorization          | Rule-based keyword matching (editable JSON config)                        |
| Monthly trends          | `groupby` + `pct_change()` for month-on-month growth                       |
| Category mix            | Pivot table (month × category)                                            |
| Recurring payments      | Seen in ≥3 months, ~once a month, coefficient of variation ≤ 15%          |
| Unusual transactions    | Z-score within each category; flagged if z > 2.5                          |
| Savings rate            | (Income − Total outflow) ÷ Income × 100                                   |
| Spending habits         | Weekday vs weekend average per day                                        |

> Transfers and investments (e.g. SIPs) are excluded from "spending" because they
> are not consumption, but they are included in total outflow and savings.

## 5. Project Structure

```
spendsense/
├── app.py                       # Flask web app — upload page + report in browser
├── main.py                      # command-line version
├── templates/
│   └── index.html               # upload page (HTML/CSS/JS, drag & drop)
├── requirements.txt
├── config/
│   └── categories.json          # keyword → category rules (edit freely)
├── src/
│   ├── loader.py                # Module 1
│   ├── categorizer.py           # Module 2
│   ├── analyzer.py              # Module 3
│   ├── insights.py              # Module 4
│   ├── visualizer.py            # Module 5a
│   ├── report.py                # Module 5b (HTML report)
│   └── pipeline.py              # runs modules 1→5, shared by app.py and main.py
├── scripts/
│   └── generate_sample_data.py  # creates a realistic 6-month demo statement
├── data/
│   └── sample_statement.csv
├── tests/
│   └── test_spendsense.py       # 11 unit tests
└── output/                      # generated: report.html, charts/, CSVs
```

## 6. How to Run

### Web app (recommended) — import your statement in the browser
```bash
pip install -r requirements.txt
python app.py
```
Open **http://127.0.0.1:5000**, choose your statement file (or click *Try with sample
data*) and the full report opens in the browser — with a searchable list of all
transactions, a CSV download and a Print / Save-as-PDF button.

### Command line
```bash

# Demo with sample data
python main.py data/sample_statement.csv --name "Kanish"

# Your own statement (download CSV/Excel from net banking)
python main.py path/to/my_statement.xlsx --name "Kanish"

# Run tests
python -m unittest discover -s tests -v
```

Open `output/report.html` in any browser.

### Using your own bank statement
1. Download the statement as **CSV or Excel** from net banking (not PDF).
2. Delete any header rows above the column titles (bank name, address, etc.) so the
   first row is the column names.
3. Run `python main.py your_file.csv`.
4. If many transactions land in "Others", add the merchant keywords to
   `config/categories.json`.

Supported column names include `Date / Txn Date / Value Date`,
`Narration / Description / Particulars`, `Withdrawal Amt. / Debit`,
`Deposit Amt. / Credit`, `Closing Balance / Balance`, or a single `Amount` column
(with optional `Dr/Cr` type).

## 7. Sample Output (demo data)

- 373 transactions over 6 months, 11 spending categories
- Food & Dining identified as the largest category (26%)
- Weekend spending ~1.9× weekday spending
- 6 recurring payments detected (rent, SIP, gym, recharge, Netflix, Spotify)
- 2 unusual transactions flagged (₹7,499 headphones, ₹1,850 train ticket)

## 8. Limitations & Future Scope

- Keyword categorization misses unknown merchants → could train an ML classifier
  (e.g. TF-IDF + Logistic Regression) on labelled transactions.
- PDF statements are not supported → could add `pdfplumber` table extraction.
- Add budget limits per category with alerts.
- Spending forecasts (time-series) and user accounts to compare statements over time.

## 9. Tech Stack

Python 3.9+, Flask (web app), HTML/CSS/JavaScript (frontend), pandas, NumPy, matplotlib, openpyxl (Excel), unittest.
