"""
analyzer.py
-----------
Module 3: All the number crunching. Takes the categorized DataFrame and
produces a dictionary of results that the insight engine, charts and report
all read from (so the maths lives in exactly one place).
"""

import numpy as np
import pandas as pd

# Money moving between your own accounts / investing is not "spending"
NON_SPEND = {"Transfers", "Investments"}


class Analyzer:
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.spend = df[(df["debit"] > 0) & (~df["category"].isin(NON_SPEND))]

    # ---------- headline numbers ----------
    def summary(self) -> dict:
        df = self.df
        income = df["credit"].sum()
        outflow = df["debit"].sum()
        spending = self.spend["debit"].sum()
        days = max((df["date"].max() - df["date"].min()).days + 1, 1)
        months = max(df["month"].nunique(), 1)
        opening = closing = None
        if df["balance"].notna().any() and (df["balance"] != 0).any():
            first = df.iloc[0]
            opening = first["balance"] - first["amount"]
            closing = df.iloc[-1]["balance"]
        return {
            "start_date": df["date"].min(),
            "end_date": df["date"].max(),
            "days": days,
            "months": months,
            "transactions": len(df),
            "total_income": income,
            "total_outflow": outflow,
            "total_spending": spending,
            "net_flow": income - outflow,
            "savings_rate": (income - outflow) / income * 100 if income else 0.0,
            "avg_daily_spend": spending / days,
            "avg_monthly_spend": spending / months,
            "largest_expense": self.spend.nlargest(1, "debit").to_dict("records"),
            "opening_balance": opening,
            "closing_balance": closing,
        }

    # ---------- breakdowns ----------
    def by_category(self) -> pd.DataFrame:
        g = (self.spend.groupby("category")["debit"]
             .agg(total="sum", count="count", average="mean")
             .sort_values("total", ascending=False))
        g["share_pct"] = g["total"] / g["total"].sum() * 100
        return g

    def monthly(self) -> pd.DataFrame:
        income = self.df.groupby("month")["credit"].sum()
        spend = self.spend.groupby("month")["debit"].sum()
        outflow = self.df.groupby("month")["debit"].sum()
        m = pd.DataFrame({"income": income, "spending": spend, "outflow": outflow}).fillna(0)
        m["savings"] = m["income"] - m["outflow"]   # same definition as summary()
        m["spend_change_pct"] = m["spending"].pct_change() * 100
        return m

    def monthly_by_category(self) -> pd.DataFrame:
        return (self.spend.pivot_table(index="month", columns="category",
                                       values="debit", aggfunc="sum").fillna(0))

    def by_weekday(self) -> pd.Series:
        order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        return self.spend.groupby("weekday")["debit"].sum().reindex(order, fill_value=0)

    def top_merchants(self, n=10) -> pd.DataFrame:
        return (self.spend.groupby("merchant")["debit"]
                .agg(total="sum", visits="count")
                .sort_values("total", ascending=False).head(n))

    def balance_trend(self) -> pd.Series:
        if self.df["balance"].isna().all():
            # No balance column -> reconstruct a running net position
            return self.df.groupby("date")["amount"].sum().cumsum()
        return self.df.groupby("date")["balance"].last()

    # ---------- pattern detection ----------
    def recurring_payments(self, min_months=3) -> pd.DataFrame:
        """Merchants charged in at least `min_months` different months with
        a fairly stable amount -> likely subscriptions / EMIs / bills."""
        rows = []
        debits = self.df[self.df["debit"] > 0]
        for merchant, g in debits.groupby("merchant"):
            months = g["month"].nunique()
            if months < min_months or len(g) > months * 1.5:  # ~once a month only
                continue
            mean = g["debit"].mean()
            cv = g["debit"].std(ddof=0) / mean if mean else 0  # coefficient of variation
            if cv <= 0.15:
                rows.append({"merchant": merchant, "category": g["category"].mode()[0],
                             "avg_amount": mean, "months_seen": months,
                             "yearly_cost": mean * 12})
        cols = ["merchant", "category", "avg_amount", "months_seen", "yearly_cost"]
        return pd.DataFrame(rows, columns=cols).sort_values("yearly_cost", ascending=False)

    def anomalies(self, z=2.5) -> pd.DataFrame:
        """Expenses unusually large compared to their own category (z-score)."""
        s = self.spend.copy()
        grp = s.groupby("category")["debit"]
        s["z_score"] = (s["debit"] - grp.transform("mean")) / grp.transform("std").replace(0, np.nan)
        out = s[s["z_score"] > z]
        return out[["date", "description", "category", "debit", "z_score"]].sort_values("debit", ascending=False)

    def run_all(self) -> dict:
        return {
            "summary": self.summary(),
            "by_category": self.by_category(),
            "monthly": self.monthly(),
            "monthly_by_category": self.monthly_by_category(),
            "by_weekday": self.by_weekday(),
            "top_merchants": self.top_merchants(),
            "balance_trend": self.balance_trend(),
            "recurring": self.recurring_payments(),
            "anomalies": self.anomalies(),
        }
