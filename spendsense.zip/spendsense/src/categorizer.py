"""
categorizer.py
--------------
Module 2: Assigns a spending category to every transaction using keyword
rules stored in config/categories.json. Rules are easy to edit without
touching code — just add a keyword under the right category.

Also extracts a short, readable "merchant" name from long bank narrations like
'UPI/412345678/SWIGGY BANGALORE/paytm@icici' -> 'Swiggy'.
"""

import json
import re
from pathlib import Path

import pandas as pd

DEFAULT_RULES = Path(__file__).resolve().parent.parent / "config" / "categories.json"

# Words that appear in narrations but are not merchant names
NOISE = {"upi", "pos", "neft", "imps", "rtgs", "ach", "nach", "debit", "credit",
         "card", "txn", "ref", "payment", "to", "from", "by", "the", "ecom", "vps",
         "ib", "mb", "inb", "billpay", "p2m", "p2p", "dr", "cr", "via", "paytm",
         "ybl", "okaxis", "okicici", "oksbi", "okhdfcbank", "icici", "hdfc", "sbi", "axl"}


class Categorizer:
    def __init__(self, rules_path=DEFAULT_RULES):
        with open(rules_path, encoding="utf-8") as fh:
            self.rules = {cat: [k.lower() for k in kws] for cat, kws in json.load(fh).items()}

    def categorize(self, description: str, is_credit: bool) -> str:
        text = f" {description.lower()} "
        if is_credit:
            # Money coming in: either a known income source or other inflow
            if any(kw in text for kw in self.rules.get("Income", [])):
                return "Income"
            return "Other Income"
        for category, keywords in self.rules.items():
            if category != "Income" and any(kw in text for kw in keywords):
                return category
        return "Others"

    @staticmethod
    def merchant(description: str) -> str:
        """Pull a short merchant / payee name out of a raw narration."""
        parts = re.split(r"[/\-|*@:]+|\s{2,}", description)
        for part in parts:
            words = [w for w in re.findall(r"[A-Za-z][A-Za-z.&']+", part)
                     if w.lower() not in NOISE]
            if words:
                return " ".join(words[:2]).title()
        return "Unknown"

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["category"] = [self.categorize(d, c > 0) for d, c in zip(df["description"], df["credit"])]
        df["merchant"] = df["description"].map(self.merchant)
        return df
