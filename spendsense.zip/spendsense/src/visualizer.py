"""
visualizer.py
-------------
Module 5a: Creates the charts (PNG files) with matplotlib. Every function
takes analysis results and returns the path of the saved image.
"""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # no GUI needed — just save files
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

from .insights import nice_month

INK = "#1f2933"
MUTED = "#7b8794"
GRID = "#e4e7eb"
INCOME = "#2f9e77"
SPEND = "#d9534f"
ACCENT = "#3b6fd8"
PALETTE = ["#3b6fd8", "#e8833a", "#2f9e77", "#c2477d", "#8a63d2",
           "#d4a72c", "#3fa7b5", "#a0522d", "#6b8e23", "#9aa5b1"]

plt.rcParams.update({
    "font.size": 10, "axes.edgecolor": GRID, "axes.labelcolor": MUTED,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.titleweight": "bold",
    "axes.titlesize": 12, "axes.titlecolor": INK, "axes.titlelocation": "left",
    "axes.spines.top": False, "axes.spines.right": False,
})

rupees = mticker.FuncFormatter(lambda x, _: f"₹{x/1000:.0f}k" if abs(x) >= 1000 else f"₹{x:.0f}")


def _save(fig, out_dir: Path, name: str) -> Path:
    path = out_dir / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def category_chart(cat, out_dir):
    data = cat["total"].head(10)[::-1]
    fig, ax = plt.subplots(figsize=(8, 4.6))
    bars = ax.barh(data.index, data.values, color=ACCENT, height=0.6)
    ax.xaxis.set_major_formatter(rupees)
    ax.grid(axis="x", color=GRID)
    ax.set_axisbelow(True)
    for b, pct in zip(bars, cat["share_pct"].head(10)[::-1]):
        ax.text(b.get_width(), b.get_y() + b.get_height() / 2, f"  {pct:.0f}%",
                va="center", color=INK, fontsize=9)
    ax.set_title("Where your money goes (by category)")
    ax.set_xlim(0, data.max() * 1.15)
    return _save(fig, out_dir, "category_breakdown")


def monthly_chart(monthly, out_dir):
    fig, ax = plt.subplots(figsize=(8, 4))
    x = range(len(monthly))
    w = 0.38
    ax.bar([i - w / 2 for i in x], monthly["income"], w, label="Money in", color=INCOME)
    ax.bar([i + w / 2 for i in x], monthly["spending"], w, label="Spending", color=SPEND)
    ax.set_xticks(list(x), [nice_month(m) for m in monthly.index])
    ax.yaxis.set_major_formatter(rupees)
    ax.grid(axis="y", color=GRID)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, loc="upper left", ncols=2)
    ax.set_title("Monthly money in vs spending")
    return _save(fig, out_dir, "monthly_trend")


def stacked_category_chart(mbc, out_dir):
    top = mbc.sum().sort_values(ascending=False).index[:6]
    data = mbc[top].copy()
    rest = mbc.drop(columns=top).sum(axis=1)
    if rest.sum() > 0:
        data["Everything else"] = rest
    fig, ax = plt.subplots(figsize=(8, 4.2))
    bottom = None
    for i, col in enumerate(data.columns):
        ax.bar([nice_month(m) for m in data.index], data[col], bottom=bottom, label=col,
               color=PALETTE[i] if col != "Everything else" else PALETTE[-1], width=0.6)
        bottom = data[col] if bottom is None else bottom + data[col]
    ax.yaxis.set_major_formatter(rupees)
    ax.grid(axis="y", color=GRID)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, fontsize=8, bbox_to_anchor=(1.01, 1), loc="upper left")
    ax.set_title("Category mix each month")
    return _save(fig, out_dir, "monthly_categories")


def balance_chart(balance, out_dir):
    fig, ax = plt.subplots(figsize=(8, 3.4))
    ax.plot(balance.index, balance.values, color=ACCENT, linewidth=2)
    ax.fill_between(balance.index, balance.values, balance.min(), color=ACCENT, alpha=0.08)
    ax.yaxis.set_major_formatter(rupees)
    ax.grid(axis="y", color=GRID)
    ax.set_title("Account balance over time")
    fig.autofmt_xdate()
    return _save(fig, out_dir, "balance_trend")


def weekday_chart(wd, out_dir):
    fig, ax = plt.subplots(figsize=(8, 3.2))
    colors = [SPEND if v == wd.max() else "#c9ced6" for v in wd.values]
    ax.bar([d[:3] for d in wd.index], wd.values, color=colors, width=0.6)
    ax.yaxis.set_major_formatter(rupees)
    ax.grid(axis="y", color=GRID)
    ax.set_axisbelow(True)
    ax.set_title("Spending by day of week")
    return _save(fig, out_dir, "weekday_pattern")


def make_all_charts(results: dict, out_dir) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    charts = {}
    if not results["by_category"].empty:
        charts["category"] = category_chart(results["by_category"], out_dir)
        charts["stacked"] = stacked_category_chart(results["monthly_by_category"], out_dir)
    charts["monthly"] = monthly_chart(results["monthly"], out_dir)
    charts["balance"] = balance_chart(results["balance_trend"], out_dir)
    charts["weekday"] = weekday_chart(results["by_weekday"], out_dir)
    return charts
