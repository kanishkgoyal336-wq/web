"""SpendSense — Bank Statement Analytics System."""

from .loader import load_statement, clean_statement, StatementError
from .categorizer import Categorizer
from .analyzer import Analyzer
from .insights import generate_insights, inr
from .visualizer import make_all_charts
from .report import build_html, print_console_summary

__all__ = ["load_statement", "clean_statement", "StatementError", "Categorizer", "Analyzer",
           "generate_insights", "inr", "make_all_charts", "build_html", "print_console_summary"]
