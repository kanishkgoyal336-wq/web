"""
report.py
---------
Module 5b: Builds a single self-contained HTML report (charts are embedded,
so the file can be emailed or opened offline) and prints a console summary.
"""

import base64
import html
from datetime import datetime
from pathlib import Path

from .insights import inr, nice_month

ICON = {"good": "✅", "warn": "⚠️", "info": "💡"}


def _img(path) -> str:
    data = base64.b64encode(Path(path).read_bytes()).decode()
    return f'<img src="data:image/png;base64,{data}" alt="{Path(path).stem}">'


def _table(df, money_cols=(), pct_cols=(), int_cols=(), date_cols=()) -> str:
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in [df.index.name or ""] + list(df.columns))
    rows = []
    for idx, row in df.iterrows():
        cells = [f"<td>{html.escape(str(idx))}</td>"]
        for c in df.columns:
            v = row[c]
            if c in money_cols:
                v = inr(v)
            elif c in pct_cols:
                v = f"{v:.1f}%"
            elif c in int_cols:
                v = f"{int(v)}"
            elif c in date_cols:
                v = f"{v:%d %b %Y}"
            elif isinstance(v, float):
                v = f"{v:.2f}"
            cls = ' class="num"' if c in money_cols + pct_cols + int_cols else ""
            cells.append(f"<td{cls}>{html.escape(str(v))}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(rows)}</tbody></table>"


CSS = """
:root{--ink:#1f2933;--muted:#7b8794;--line:#e4e7eb;--bg:#f7f8fa;--card:#fff;
--good:#2f9e77;--warn:#d9534f;--accent:#3b6fd8}
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
color:var(--ink);background:var(--bg);line-height:1.5}
.wrap{max-width:960px;margin:0 auto;padding:32px 16px 64px}
h1{margin:0;font-size:28px}h2{font-size:18px;margin:36px 0 12px}
.sub{color:var(--muted);margin:4px 0 24px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.kpi .l{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
.kpi .v{font-size:22px;font-weight:700;margin-top:4px}
.pos{color:var(--good)}.neg{color:var(--warn)}
.ins{list-style:none;padding:0;margin:0;display:grid;gap:8px}
.ins li{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--accent);
border-radius:8px;padding:10px 14px}
.ins li.warn{border-left-color:var(--warn)}.ins li.good{border-left-color:var(--good)}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:14px}
img{width:100%;height:auto;display:block}
table{width:100%;border-collapse:collapse;background:var(--card);font-size:14px}
th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left}
th{font-size:12px;color:var(--muted);text-transform:uppercase}td.num{text-align:right;font-variant-numeric:tabular-nums}
.tw{overflow-x:auto;border:1px solid var(--line);border-radius:10px}
footer{color:var(--muted);font-size:12px;margin-top:40px}
.filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
.filters input,.filters select{padding:8px 10px;border:1px solid var(--line);border-radius:8px;font:inherit;background:#fff}
.filters input{flex:1;min-width:200px}
.scroll{max-height:480px;overflow-y:auto}.scroll thead th{position:sticky;top:0;background:#fff}
@media print{.toolbar,.filters{display:none}.scroll{max-height:none}}
.toolbar{display:flex;gap:8px;justify-content:flex-end;margin-bottom:16px;flex-wrap:wrap}
.btn{display:inline-block;padding:8px 14px;border-radius:8px;border:1px solid var(--line);background:#fff;
color:var(--ink);text-decoration:none;font-size:14px;font-weight:600}.btn.primary{background:var(--accent);color:#fff;border-color:var(--accent)}
"""


def _transactions_section(df) -> str:
    """Searchable / filterable table of every transaction (plain JavaScript)."""
    cats = sorted(df["category"].unique())
    opts = "".join(f'<option>{html.escape(c)}</option>' for c in cats)
    rows = []
    for r in df.sort_values("date", ascending=False).itertuples():
        amt = f'<span class="pos">+{inr(r.credit)}</span>' if r.credit > 0 else f'<span class="neg">-{inr(r.debit)}</span>'
        rows.append(f'<tr data-cat="{html.escape(r.category)}"><td>{r.date:%d %b %Y}</td>'
                    f'<td>{html.escape(r.description)}</td><td>{html.escape(r.category)}</td>'
                    f'<td class="num">{amt}</td></tr>')
    return f"""<h2>All transactions</h2>
<div class="filters"><input id="q" type="search" placeholder="Search description, e.g. swiggy">
<select id="cat"><option value="">All categories</option>{opts}</select>
<span id="cnt" class="sub"></span></div>
<div class="tw scroll"><table id="tx"><thead><tr><th>Date</th><th>Description</th><th>Category</th>
<th class="num">Amount</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<script>
(function(){{
  const q=document.getElementById('q'), c=document.getElementById('cat'), n=document.getElementById('cnt');
  const rows=[...document.querySelectorAll('#tx tbody tr')];
  function f(){{ const t=q.value.toLowerCase(), k=c.value; let v=0;
    rows.forEach(r=>{{ const ok=(!k||r.dataset.cat===k)&&r.textContent.toLowerCase().includes(t);
      r.style.display=ok?'':'none'; if(ok) v++; }});
    n.textContent=v+' of '+rows.length+' shown'; }}
  q.addEventListener('input',f); c.addEventListener('change',f); f();
}})();
</script>"""


def build_html(results, insights, charts, out_path, title="Bank Statement Analysis",
               df=None, toolbar="") -> Path:
    s = results["summary"]
    net_cls = "pos" if s["net_flow"] >= 0 else "neg"
    kpis = [
        ("Money in", inr(s["total_income"]), ""),
        ("Spending", inr(s["total_spending"]), ""),
        ("Net savings", inr(s["net_flow"]), net_cls),
        ("Savings rate", f"{s['savings_rate']:.1f}%", net_cls),
        ("Avg spend / day", inr(s["avg_daily_spend"]), ""),
        ("Transactions", f"{s['transactions']}", ""),
    ]
    if s["closing_balance"] is not None:
        kpis.append(("Closing balance", inr(s["closing_balance"]), ""))

    kpi_html = "".join(f'<div class="kpi"><div class="l">{l}</div><div class="v {c}">{v}</div></div>'
                       for l, v, c in kpis)
    ins_html = "".join(f'<li class="{lvl}">{ICON[lvl]} {html.escape(msg)}</li>' for lvl, msg in insights)
    chart_html = lambda k: f'<div class="card">{_img(charts[k])}</div>' if k in charts else ""

    cat = results["by_category"].rename(columns={"total": "Total", "count": "Txns",
                                                  "average": "Average", "share_pct": "Share"})
    cat.index.name = "Category"
    merch = results["top_merchants"].rename(columns={"total": "Total", "visits": "Txns"})
    merch.index.name = "Merchant"
    monthly = results["monthly"][["income", "spending", "savings"]].rename(
        columns={"income": "Money in", "spending": "Spending", "savings": "Saved"})
    monthly.index = [nice_month(m) for m in monthly.index]
    monthly.index.name = "Month"

    rec = results["recurring"].set_index("merchant").rename(columns={
        "category": "Category", "avg_amount": "Avg amount", "months_seen": "Months", "yearly_cost": "Yearly cost"})
    rec.index.name = "Merchant"
    an = results["anomalies"].head(10).set_index("date").rename(columns={
        "description": "Description", "category": "Category", "debit": "Amount", "z_score": "Z-score"})
    an.index = an.index.strftime("%d %b %Y")
    an.index.name = "Date"

    sections = [
        "<h2>Key insights</h2>", f'<ul class="ins">{ins_html}</ul>',
        "<h2>Spending by category</h2>", chart_html("category"),
        f'<div class="tw">{_table(cat, money_cols=("Total", "Average"), pct_cols=("Share",), int_cols=("Txns",))}</div>',
        "<h2>Monthly trend</h2>", chart_html("monthly"), chart_html("stacked"),
        f'<div class="tw">{_table(monthly, money_cols=("Money in", "Spending", "Saved"))}</div>',
        "<h2>Balance & habits</h2>", chart_html("balance"), chart_html("weekday"),
        "<h2>Top merchants</h2>",
        f'<div class="tw">{_table(merch, money_cols=("Total",), int_cols=("Txns",))}</div>',
    ]
    if not rec.empty:
        sections += ["<h2>Recurring payments (subscriptions & bills)</h2>",
                     f'<div class="tw">{_table(rec, money_cols=("Avg amount", "Yearly cost"), int_cols=("Months",))}</div>']
    if not an.empty:
        sections += ["<h2>Unusual transactions</h2>",
                     f'<div class="tw">{_table(an, money_cols=("Amount",))}</div>']
    if df is not None:
        sections.append(_transactions_section(df))

    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>
<style>{CSS}</style></head><body><div class="wrap">
{toolbar}
<h1>{html.escape(title)}</h1>
<p class="sub">{s['start_date']:%d %b %Y} – {s['end_date']:%d %b %Y} · {s['days']} days · {s['transactions']} transactions</p>
<div class="kpis">{kpi_html}</div>
{''.join(sections)}
<footer>Generated by SpendSense on {datetime.now():%d %b %Y, %H:%M}. Transfers and investments are excluded from "spending".</footer>
</div></body></html>"""
    out_path = Path(out_path)
    out_path.write_text(page, encoding="utf-8")
    return out_path


def print_console_summary(results, insights):
    s = results["summary"]
    line = "─" * 60
    print(f"\n{line}\n  SPENDSENSE — BANK STATEMENT ANALYSIS\n{line}")
    print(f"  Period        : {s['start_date']:%d %b %Y} → {s['end_date']:%d %b %Y} ({s['days']} days)")
    print(f"  Transactions  : {s['transactions']}")
    print(f"  Money in      : {inr(s['total_income'])}")
    print(f"  Spending      : {inr(s['total_spending'])}")
    print(f"  Net savings   : {inr(s['net_flow'])}  ({s['savings_rate']:.1f}% savings rate)")
    print(f"  Avg per day   : {inr(s['avg_daily_spend'])}")
    print(f"{line}\n  SPENDING BY CATEGORY")
    for name, row in results["by_category"].iterrows():
        bar = "█" * int(row["share_pct"] / 2)
        print(f"  {name:<20} {inr(row['total']):>10}  {row['share_pct']:5.1f}%  {bar}")
    print(f"{line}\n  INSIGHTS")
    for lvl, msg in insights:
        print(f"  {ICON[lvl]} {msg}")
    print(line)
