"""
insights.py
-----------
Module 4: Turns raw numbers into plain-English explanations of where the
money went and what could be improved. Each rule looks at one aspect of the
analysis and, if something noteworthy is found, writes a sentence about it.
"""

import pandas as pd


def inr(x: float) -> str:
    """Format a number as Indian Rupees with Indian digit grouping (12,34,567)."""
    neg = x < 0
    x = abs(round(float(x)))
    s = str(int(x))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        s = ",".join(groups) + "," + tail
    return ("-₹" if neg else "₹") + s


def nice_month(m: str) -> str:
    """'2026-04' -> 'Apr 2026'"""
    return pd.Period(m, freq="M").strftime("%b %Y")


def generate_insights(r: dict) -> list:
    """Return a list of (level, message) tuples. level: good | warn | info"""
    out = []
    s = r["summary"]
    cat = r["by_category"]
    monthly = r["monthly"]

    # 1. Savings health
    rate = s["savings_rate"]
    if s["total_income"] == 0:
        out.append(("warn", "No incoming money was found in this period, so every rupee spent "
                            "came from your existing balance."))
    elif rate >= 20:
        out.append(("good", f"You saved {rate:.0f}% of what came in ({inr(s['net_flow'])}). "
                            "A savings rate above 20% is a healthy habit — keep it up."))
    elif rate >= 0:
        out.append(("info", f"You saved {rate:.0f}% of your income. Aiming for 20% would mean "
                            f"saving about {inr(s['total_income'] * 0.2 - s['net_flow'])} more over this period."))
    else:
        out.append(("warn", f"You spent {inr(-s['net_flow'])} more than you received. "
                            "Your balance is shrinking — look at the top categories below first."))

    # 2. Biggest category
    if not cat.empty:
        top = cat.index[0]
        out.append(("info", f"'{top}' is your biggest expense at {inr(cat.iloc[0]['total'])} "
                            f"({cat.iloc[0]['share_pct']:.0f}% of spending, {int(cat.iloc[0]['count'])} transactions)."))
        if len(cat) >= 3:
            top3 = cat.head(3)["share_pct"].sum()
            out.append(("info", f"Your top 3 categories ({', '.join(cat.index[:3])}) make up "
                                f"{top3:.0f}% of all spending — that's where cutting back would matter most."))

    # 3. Food delivery habit
    if "Food & Dining" in cat.index:
        f = cat.loc["Food & Dining"]
        per_month = f["total"] / s["months"]
        if f["share_pct"] > 15:
            out.append(("warn", f"Food & dining averages {inr(per_month)} per month "
                                f"({f['share_pct']:.0f}% of spending). Cooking a few more meals "
                                f"a week could save roughly {inr(per_month * 0.3)} a month."))

    # 4. Month-on-month trend
    if len(monthly) >= 2:
        last, prev = monthly.iloc[-1], monthly.iloc[-2]
        change = last["spend_change_pct"]
        if pd.notna(change):
            direction = "up" if change > 0 else "down"
            level = "warn" if change > 15 else ("good" if change < -5 else "info")
            out.append((level, f"Spending in {nice_month(monthly.index[-1])} was {direction} {abs(change):.0f}% "
                               f"vs {nice_month(monthly.index[-2])} ({inr(prev['spending'])} → {inr(last['spending'])})."))
        worst = monthly["spending"].idxmax()
        out.append(("info", f"Your most expensive month was {nice_month(worst)} with {inr(monthly.loc[worst, 'spending'])} spent."))

    # 5. Weekday pattern
    wd = r["by_weekday"]
    if wd.sum() > 0:
        weekend = wd[["Saturday", "Sunday"]].sum() / 2
        weekday = wd.drop(["Saturday", "Sunday"]).sum() / 5
        if weekday > 0 and weekend > weekday * 1.3:
            out.append(("info", f"You spend about {weekend / weekday:.1f}x more on an average weekend day "
                                "than on a weekday. Weekend outings are a big driver."))
        out.append(("info", f"{wd.idxmax()} is the day you spend the most."))

    # 6. Recurring payments
    rec = r["recurring"]
    if not rec.empty:
        out.append(("info", f"Found {len(rec)} recurring payment(s) costing about "
                            f"{inr(rec['yearly_cost'].sum())} per year: {', '.join(rec['merchant'].head(5))}. "
                            "Check whether you still need the optional ones."))

    # 7. Unusual transactions
    an = r["anomalies"]
    if not an.empty:
        a = an.iloc[0]
        out.append(("warn", f"{len(an)} unusually large transaction(s) detected. The biggest was "
                            f"{inr(a['debit'])} on {a['date']:%d %b %Y} ({a['category']}) — "
                            f"{a['z_score']:.1f} standard deviations above your normal for that category."))

    # 8. Cash usage
    if "Cash Withdrawal" in cat.index and cat.loc["Cash Withdrawal", "share_pct"] > 10:
        out.append(("info", f"{cat.loc['Cash Withdrawal', 'share_pct']:.0f}% of outflow was ATM cash, which "
                            "can't be tracked. Paying by UPI/card gives you a clearer picture."))

    return out
