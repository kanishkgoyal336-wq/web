"""
pipeline.py
-----------
Runs the full pipeline in one call. Used by both the command-line tool
(main.py) and the web app (app.py) so the logic lives in one place.

    Load → Categorize → Analyze → Insights → Charts → HTML report
"""

from pathlib import Path

from .analyzer import Analyzer
from .categorizer import Categorizer
from .insights import generate_insights
from .loader import load_statement
from .report import build_html
from .visualizer import make_all_charts


def analyze_statement(statement_path, out_dir, name=None, rules=None, toolbar="", verbose=False):
    """Analyze one statement file. Returns a dict with the data, results and file paths."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    log = print if verbose else (lambda *a, **k: None)

    log(f"[1/5] Loading statement: {statement_path}")
    df = load_statement(statement_path)

    log(f"[2/5] Categorizing {len(df)} transactions")
    df = (Categorizer(rules) if rules else Categorizer()).apply(df)

    log("[3/5] Analyzing spending patterns")
    results = Analyzer(df).run_all()

    log("[4/5] Generating insights")
    insights = generate_insights(results)

    log("[5/5] Creating charts and report")
    charts = make_all_charts(results, out_dir / "charts")
    title = f"{name}'s Spending Analysis" if name else "Bank Statement Analysis"
    report = build_html(results, insights, charts, out_dir / "report.html",
                        title=title, df=df, toolbar=toolbar)

    csv_path = out_dir / "categorized_transactions.csv"
    df.to_csv(csv_path, index=False)
    results["by_category"].to_csv(out_dir / "category_summary.csv")
    results["monthly"].to_csv(out_dir / "monthly_summary.csv")

    return {"df": df, "results": results, "insights": insights,
            "report": report, "csv": csv_path}
