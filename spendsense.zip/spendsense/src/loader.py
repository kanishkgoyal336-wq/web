"""
loader.py
---------
Module 1: Loads a bank statement (CSV or Excel) and converts it into a
clean, standard format that the rest of the system can rely on.

Every bank names its columns differently (e.g. "Narration" vs "Description",
"Withdrawal Amt." vs "Debit"), so we map known aliases to one standard schema:

    date | description | debit | credit | balance
"""

from pathlib import Path

import numpy as np
import pandas as pd

# Standard column -> list of names banks commonly use for it (lower-case).
COLUMN_ALIASES = {
    "date": ["date", "txn date", "transaction date", "value date", "posting date", "tran date"],
    "description": ["description", "narration", "particulars", "details",
                    "transaction details", "remarks", "transaction remarks"],
    "debit": ["debit", "withdrawal", "withdrawal amt.", "withdrawal amount",
              "withdrawal amt", "debit amount", "dr", "amount debited"],
    "credit": ["credit", "deposit", "deposit amt.", "deposit amount",
               "deposit amt", "credit amount", "cr", "amount credited"],
    "balance": ["balance", "closing balance", "available balance", "running balance", "bal"],
    "amount": ["amount", "transaction amount", "amt"],
    "type": ["type", "dr/cr", "cr/dr", "transaction type"],
}


class StatementError(Exception):
    """Raised when a statement cannot be understood."""


def _read_raw(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in (".xlsx", ".xls"):
        return pd.read_excel(path)
    raise StatementError(f"Unsupported file type '{suffix}'. Use .csv, .xlsx or .xls")


def _map_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename the bank's column names to our standard names."""
    rename = {}
    for col in df.columns:
        key = str(col).strip().lower()
        for standard, aliases in COLUMN_ALIASES.items():
            if key in aliases and standard not in rename.values():
                rename[col] = standard
                break
    return df.rename(columns=rename)


def _to_number(series: pd.Series) -> pd.Series:
    """Convert values like '1,250.00', '₹500', '' or NaN into floats."""
    cleaned = (series.astype(str)
               .str.replace(r"[₹,\s]", "", regex=True)
               .replace({"": np.nan, "nan": np.nan, "None": np.nan, "-": np.nan}))
    return pd.to_numeric(cleaned, errors="coerce").fillna(0.0)


def clean_statement(df: pd.DataFrame) -> pd.DataFrame:
    """Standardise a raw statement DataFrame."""
    df = _map_columns(df.copy())

    if "date" not in df.columns or "description" not in df.columns:
        raise StatementError(
            "Could not find a Date and Description/Narration column. "
            f"Columns found: {list(df.columns)}"
        )

    # Case A: separate debit / credit columns (most Indian banks)
    if "debit" in df.columns or "credit" in df.columns:
        df["debit"] = _to_number(df["debit"]) if "debit" in df.columns else 0.0
        df["credit"] = _to_number(df["credit"]) if "credit" in df.columns else 0.0
    # Case B: single amount column, sign or DR/CR flag tells direction
    elif "amount" in df.columns:
        amt = _to_number(df["amount"])
        if "type" in df.columns:
            is_debit = df["type"].astype(str).str.strip().str.upper().str.startswith("D")
            amt = amt.abs().where(~is_debit, -amt.abs())
        df["debit"] = (-amt).clip(lower=0)
        df["credit"] = amt.clip(lower=0)
    else:
        raise StatementError("Could not find Debit/Credit or Amount columns.")

    df["date"] = pd.to_datetime(df["date"], dayfirst=True, errors="coerce", format="mixed")
    df["description"] = df["description"].astype(str).str.strip()
    df = df.dropna(subset=["date"])
    df = df[(df["debit"] > 0) | (df["credit"] > 0)]

    if "balance" in df.columns:
        df["balance"] = _to_number(df["balance"])
    else:
        df["balance"] = np.nan

    df = df[["date", "description", "debit", "credit", "balance"]]
    df = df.sort_values("date", kind="stable").reset_index(drop=True)

    # Helpful derived columns for analysis
    df["amount"] = df["credit"] - df["debit"]          # +ve = money in, -ve = money out
    df["month"] = df["date"].dt.to_period("M").astype(str)       # e.g. '2026-04' (sorts correctly)
    df["weekday"] = df["date"].dt.day_name()
    return df


def load_statement(path) -> pd.DataFrame:
    """Read a statement file from disk and return the cleaned DataFrame."""
    path = Path(path)
    if not path.exists():
        raise StatementError(f"File not found: {path}")
    df = clean_statement(_read_raw(path))
    if df.empty:
        raise StatementError("No valid transactions found in the statement.")
    return df
